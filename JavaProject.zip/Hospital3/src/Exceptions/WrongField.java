package Exceptions;

public class WrongField extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public WrongField(String msg){
		super(msg);
	}
}