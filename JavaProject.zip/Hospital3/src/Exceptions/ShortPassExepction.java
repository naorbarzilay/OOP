package Exceptions;

public class ShortPassExepction extends Exception{

	private static final long serialVersionUID = 1L;
	
	public ShortPassExepction(String msg){
		super(msg);
	}
}