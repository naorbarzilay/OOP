package Exceptions;

public class UserTakenException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserTakenException(String msg){
		super(msg);
	}
} 


