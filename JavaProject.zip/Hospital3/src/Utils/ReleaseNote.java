package Utils;

public enum ReleaseNote {
	
	CAN_GO_HOME,MOVE_TO_HOTEL,STANDBY

}
