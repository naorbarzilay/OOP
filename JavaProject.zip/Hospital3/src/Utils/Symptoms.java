package Utils;

public enum Symptoms {
	
	COUGH
	,FEVER
	,TIREDNESS
	,DIFFICULTY_BREATHING,
	BACKHACHES,
	FAINTING

}
